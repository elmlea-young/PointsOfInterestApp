//
//  FilterViewController.swift
//  PointsOfInterestApp
//
//  Created by Emily Rose Young on 13/12/2016.
//  Copyright © 2016 Emily Rose Young. All rights reserved.
//

import UIKit

var chosenChoices = [String]() // holds a list of the place types which the user selected from the filter

class FilterViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var table: UITableView!
    var listOfTypes = [String]() // Holds the list of types of places
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getTypes()
    }
    
    // Parses the JSON to find what types of places are in the results
    func getTypes(){
        
        if let results = mapResults["results"] as? [[String: AnyObject]] {
      
            for place in results{
                
               if let types = place["types"] as? [String]{
                
                   for type in types{
                    
                        if let _ = listOfTypes.index(of: type) { // checks if the type already exists in the list
                        
                        }else{
                    
                            listOfTypes.append(type) // adds the type to the list if not already there
                        }
                    }
                }
            }
        }
        table.reloadData()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows
        return listOfTypes.count // number of types in the list
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "myCell")
        cell.textLabel?.text = listOfTypes[indexPath.row] // cell text is each type from listOftypes
        return cell
    }
    
    // add title of selected cell to list of choices
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        chosenChoices.append(listOfTypes[indexPath.row])
    }
    
    // remove the title of deselected cell rom choices
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
        if let index = chosenChoices.index(of: listOfTypes[indexPath.row]) {
            chosenChoices.remove(at: index)
        }
    }
    
    // when view loads, show which cells were already selected, if any
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let _ = chosenChoices.index(of: listOfTypes[indexPath.row]){ // checks which cells the user had selected, marks them as selected
            // weird bug, to be able to deselect the cell again -
            cell.isSelected = true
            table.selectRow(at: indexPath, animated: true, scrollPosition: .none )
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
