//
//  MoreDetailsViewController.swift
//  PointsOfInterestApp
//
//  Created by Emily Rose Young on 14/12/2016.
//  Copyright © 2016 Emily Rose Young. All rights reserved.
//

import UIKit

class MoreDetailsViewController: UIViewController {

    @IBOutlet weak var website: UITextView!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var address: UILabel!
    @IBOutlet weak var number: UILabel!
    
    var detailedResults = NSDictionary() // holds JSON for the detailed place results
    var photoReference = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set up tap recognition for phone call
        let tap = UITapGestureRecognizer(target: self, action: #selector(MoreDetailsViewController.tapFunction))
        number.isUserInteractionEnabled = true
        number.addGestureRecognizer(tap)
        
        //reset values
        var run = true // flag to stop while loop
        detailedResults = [:]
        
        getDetails() // requests JSON result
        
        while (run == true){
            if detailedResults != [:]{ // waits until results have been returned
                run = false
                setDetails() // sets labels and text on view
                setPhoto() // sets photo on view
            }
        }
    }
    
    // Should make phone call when phone number labe is pressed, but can't test on simulator
    func tapFunction(sender:UITapGestureRecognizer) {
        if let phoneCallURL:NSURL = NSURL(string:"tel://\(number.text)") {
            let application:UIApplication = UIApplication.shared
            if (application.canOpenURL(phoneCallURL as URL)) {
                application.open(phoneCallURL as URL)
            }
        }
    }
    
    // Gets the JSON result for more details on the place.
    func getDetails(){
        
        let tempURL = buildURL()
        let url = URL(string: tempURL)!
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error)
                
            } else {
                if let urlContent = data {
                    
                    do {
                        let jsonResult = try JSONSerialization.jsonObject(with: urlContent, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        
                       // print(jsonResult)
                        self.detailedResults = jsonResult as! NSDictionary
                        
                    } catch {
                        print("======\nJSON processing Failed\n=======")
                    }
                }
            }
        }
        
        task.resume()
        
    }
    
    // Parses JSON to get address, number, website and photo reference. Sets labels to show the text
    func setDetails(){
        
        if let results = detailedResults["result"] as? [String: AnyObject]{
            
            if let getAddress = results["formatted_address"] as? String{
                address.text = getAddress
            }
            if let getNumber = results["formatted_phone_number"] as? String{
                number.text = getNumber
            }
            if let getURL = results["website"] as? String{
                website.text = getURL
            }
            if let photoDeets = results["photos"] as? [[String: AnyObject]]{
                
                for element in photoDeets{
                    
                    if let reference = element["photo_reference"] as? String{
                        photoReference = reference
                    }
                }
            }
        }
    }
    
    func setPhoto(){
        let tempUrl = buildPhotoURL() // get URL for returning photo
        let url = NSURL(string:tempUrl)
        let data = NSData(contentsOf:url! as URL) // gets photo
        if data != nil { // set image on view if photo exists
            image.image = UIImage(data:data! as Data)
        }
    }
    
    // builds URL for returning the photo. Uses photo reference and api key
    func buildPhotoURL() -> String{
        let urlString = "https://maps.googleapis.com/maps/api/place/photo?maxwidth=300&maxheight=300&photoreference=\(photoReference)&key=\(apiKey)"
        return urlString
    }
    
    // builds URL for more details using placeID and apiKey
    func buildURL() -> String{
        let urlString = "https://maps.googleapis.com/maps/api/place/details/json?placeid=\(placeID)&key=\(apiKey)"
    
        return urlString
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
