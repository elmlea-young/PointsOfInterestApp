//
//  MapViewController.swift
//  PointsOfInterestApp

//
//  Created by Emily Rose Young on 08/12/2016.
//  Copyright © 2016 Emily Rose Young. All rights reserved.
//

import UIKit
import MapKit

var mapResults = NSDictionary() // JSON result
var placeID = String()
let apiKey = "AIzaSyDu5YobwvEGe7gpf79n57kWWDmpnQ2A450"

class MapViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var table: UITableView!
    @IBOutlet weak var searchBar: UISearchBar!
    
    var listOfPlaceNames = [String]() // List of place names from json for result table
    var distanceValue = 1.0
    var placesLength = 0 // how many places are returned in JSON
    var userLocation = CLLocationCoordinate2D(latitude: 53.406566, longitude: -2.966531) // start at ashton Building
    var ashtonBuilding = CLLocationCoordinate2D(latitude: 53.406566, longitude: -2.966531)
    let regionRadius: CLLocationDistance = 1000 // range visible on screen
    
    override func viewDidLoad() {
        super.viewDidLoad()
        table.isHidden = true // don't show table at first
        addCurrentLocationPin(location: userLocation)
        searchBar.delegate = self
        mapView.delegate = self
    }
    
    override func viewDidAppear(_ animated: Bool) {
        centerMapOnLocation(location: userLocation) //make sure map is in correct position
        
        if chosenChoices.count > 0{ // if user has filtered results reset the pins on the map
            addPinsToMapFiltered()
        }
    }
    
    // resets the map to userlocation at proper zoom
    func centerMapOnLocation(location: CLLocationCoordinate2D) {
        let span = MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
        let region = MKCoordinateRegion(center: location, span: span)
        self.mapView.setRegion(region, animated: true)
        self.addCurrentLocationPin(location: self.userLocation)
    }
    
    // add pin on user's location
    func addCurrentLocationPin(location: CLLocationCoordinate2D){
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        self.mapView.addAnnotation(annotation)
    }
    
    // gets list of places JSON
    func doSearch(){
        
        let tempURL = buildURL()
        let url = URL(string: tempURL)!
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            if error != nil {
                print(error)
                
            } else {
                if let urlContent = data {
                    
                    do {
                        let jsonResult = try JSONSerialization.jsonObject(with: urlContent, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject
                        
                        print(jsonResult)
                        mapResults = jsonResult as! NSDictionary
                        
                    } catch {
                        print("======\nJSON processing Failed\n=======")
                    }
                }
            }
        }
        task.resume()
    }
    
    // returns URL string for using user location, radius, and api key
    func buildURL() -> String{
        let urlString = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=\(userLocation.latitude),\(userLocation.longitude)&radius=\(String(distanceValue*1000))&key=\(apiKey)"
        return urlString
    }
    
    // Parses JSON to get lat and lon values for each place in the JSON, then adds a pin for each
    func addPinsToMapOriginal(){
        
        // clear current pins first
        let allAnnotations = self.mapView.annotations
        self.mapView.removeAnnotations(allAnnotations)
        addCurrentLocationPin(location: userLocation)
        
        // reset values
        placesLength = 0
        listOfPlaceNames = []
        
        if let results = mapResults["results"] as? [[String: AnyObject]] {
            
            for place in results{
                
                if let geometry = place["geometry"] as? [String:Any]{
                    
                    if let location = geometry["location"] as? [String:Any]{
                        
                        var lat = 0.0
                        var lng = 0.0
                        
                        if let latitude = location["lat"] as? Double{
                            lat = latitude
                            
                            if let longitude = location["lng"] as? Double{
                                
                                lng = longitude
                                let location = CLLocationCoordinate2D(latitude: lat, longitude: lng) // set location values
                                
                                placesLength += 1
                                
                                // add place name to list of names for the result table
                                // adds pin to map
                                if let name = place["name"] as? String{
                                    listOfPlaceNames.append(name)
                                    addAnnotation(location: location, name: name)
                                }
                            }
                        }
                    }
                }
            }
        }
        
        table.reloadData()
    }
    
    // ONLY RUNS WHEN USER FILTERED RESULTS
    // Same as above but also checks the place's types to only display results which match the user's filter choices
    func addPinsToMapFiltered(){
        
        // clear current pins first
        let allAnnotations = self.mapView.annotations
        self.mapView.removeAnnotations(allAnnotations)
        addCurrentLocationPin(location: userLocation)
        
        // reset variables
        placesLength = 0;
        listOfPlaceNames = []
        
        //parse JSON to get lon and lat values for each place
        if let results = mapResults["results"] as? [[String: AnyObject]] {

            for place in results{
                
                var added = false; // flag to say this place hasn't been added to the list yet
                
                if let types = place["types"] as? [String]{
                    
                    for type in types{
                        
                        if let _ = chosenChoices.index(of: type){ // if place's type is a chosen filter, add a pin to the map:
                            
                            if added == false{ // only add if this place wasn't already added (might have multiple types which are chosen filters)
                            
                                if let geometry = place["geometry"] as? [String:Any]{
                                
                                    if let location = geometry["location"] as? [String:Any]{
                                    
                                        var lat = 0.0
                                        var lng = 0.0
                                    
                                        if let latitude = location["lat"] as? Double{
                                            lat = latitude
                                        
                                            if let longitude = location["lng"] as? Double{
                                            
                                                lng = longitude
                                                let location = CLLocationCoordinate2D(latitude: lat, longitude: lng) // set location values
                                            
                                                placesLength += 1
                                                
                                                // gets name of place and adds it to the list of names for the table
                                                if let name = place["name"] as? String{
                                                    listOfPlaceNames.append(name)
                                                    // adds a pin to the map
                                                    addAnnotation(location: location, name: name)
                                                }
                                                added = true // flag that this place has been added now
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        table.reloadData()
    }
    
    // sets pin's details and adds to map
    func addAnnotation(location: CLLocationCoordinate2D, name: String){
        let annotation = MKPointAnnotation()
        annotation.coordinate = location // coords of pin
        annotation.title = name // title when pin is clicked
        annotation.subtitle = "\(getDistance(location: location))km" // also shows distance from current location
        self.mapView.addAnnotation(annotation)
    }
    
    // returns value for distance of location from userlocation in km
    func getDistance(location: CLLocationCoordinate2D) -> String{
        
        //set start and finiah locations
        let start = CLLocation(latitude: userLocation.latitude, longitude: userLocation.longitude)
        let end = CLLocation(latitude: location.latitude, longitude: location.longitude)
        
        var distance = start.distance(from: end) // gets distance
        distance = round(distance) // round to whole number
        
        return String(distance) // return as string
    }
    
    // runs when toolbar search button is clicked
    @IBAction func searchBtn(_ sender: AnyObject) {
        
        // toggle table visibility on screen
        if table.isHidden == true{
            table.isHidden = false
        }else{
            table.isHidden = true
        }
        
        //reset values
        var run = true // flag to stop while loop
        mapResults = [:]
        placesLength = 0
        
        doSearch() // gets JSON
        
        while (run == true){ // waits for search to finish
            
            if mapResults != [:]{ // search finished when map results isn't empty
                
                if chosenChoices.count > 0{ //if user has chosen to filter results -
                    
                   addPinsToMapFiltered()
                    run = false
                    
                }else{ // show all results
                    
                    addPinsToMapOriginal()
                    run = false
                    
                }
            }
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return the number of rows
        return placesLength
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCellStyle.default, reuseIdentifier: "Cell")
        cell.textLabel?.text = listOfPlaceNames[indexPath.row] // cell text got from listOfPlaces array
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        getPlaceID(index: indexPath.row) // get the JSON id of the selected place
        // switch to more detailed view of chosen place
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let destination = storyboard.instantiateViewController(withIdentifier: "MoreDetailsViewController") as! MoreDetailsViewController
        navigationController?.pushViewController(destination, animated: true)
    }
    
    // parses JSON to get placeID of chosen place
    func getPlaceID(index: Int){
        
        let name = listOfPlaceNames[index]
        
        if let results = mapResults["results"] as? [[String: AnyObject]] {
            
            for place in results{
                
                if let placeName = place["name"] as? String{
                    
                    if placeName == name{
                        
                        if let id = place["place_id"] as? String{
                            placeID = id
                        }
                    }
                }
            }
        }
    }
    
    // if user searched a postcode, move to that location
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if searchBar.text != ""{
            forwardGeocoding(address: searchBar.text!)
        }
    }
    
    // uses the postcode to get ,lat and lon values
    func forwardGeocoding(address: String) {
        
        searchBar.resignFirstResponder()
        CLGeocoder().geocodeAddressString(address, completionHandler: { (placemarks, error) in
            if error != nil { // invalid postcode
                print(error)
                return
            }
            if (placemarks?.count)! > 0 {
                let placemark = placemarks?[0]
                let location = placemark?.location
                let coordinate = location?.coordinate
                if (placemark?.areasOfInterest?.count)! > 0 {
                    
                    // set new userlocation
                    self.userLocation.latitude = (coordinate?.latitude)!
                    self.userLocation.longitude = (coordinate?.longitude)!
                    
                    // change map location
                    self.centerMapOnLocation(location: self.userLocation)
                    self.table.isHidden = true
                    
                } else {
                    print("No area of interest found.")
                }
            }
        })
    }
    
    //exectues when 'centre' button is pressed
    @IBAction func centreLocationBtn(_ sender: AnyObject) {
        userLocation = ashtonBuilding // reset location
        centerMapOnLocation(location: userLocation)
    }
    
    // event when pin is pressed, adds route to selected pin
    func mapView(_ mapView: MKMapView, didSelect view: MKAnnotationView) {
        let tappedPin = CLLocationCoordinate2D(latitude: (view.annotation?.coordinate.latitude)!, longitude: (view.annotation?.coordinate.longitude)!)
        
        mapView.removeOverlays(mapView.overlays) // remove current route
        
        getRoute(endLocation: tappedPin) // add route to selected pin
    }
    
    // finds route between selected point and current/searched location
    func getRoute(endLocation: CLLocationCoordinate2D){
    
        let sourceLocation = userLocation // start location
        let destinationLocation = endLocation // end location
    
        let sourcePlacemark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        let destinationPlacemark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
    
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
    
        let directionRequest = MKDirectionsRequest()
        directionRequest.source = sourceMapItem
        directionRequest.destination = destinationMapItem
        directionRequest.transportType = .walking
    
        // Calculate the direction
        let directions = MKDirections(request: directionRequest)
    
        directions.calculate {
            (response, error) -> Void in
    
            guard let response = response else {
                if let error = error {
                    print("Error: \(error)")
                }
    
                return
            }
    
            let route = response.routes[0]
            self.mapView.add((route.polyline), level: MKOverlayLevel.aboveRoads) // adds line to map
            
            // sets new level of zoom on the map
            let rect = route.polyline.boundingMapRect
            let span = MKCoordinateSpan(latitudeDelta: 0.008, longitudeDelta: 0.008)
            let region = MKCoordinateRegion(center: (MKCoordinateRegionForMapRect(rect).center), span: span)
            self.mapView.setRegion(region, animated: true)
            
        }
    }
    
    // adds route line to map
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        
        // sets line's properties
        let renderer = MKPolylineRenderer(overlay: overlay)
        renderer.strokeColor = UIColor.red
        renderer.lineWidth = 4.0
        
        return renderer
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
